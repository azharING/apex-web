Apex Academy website
====================
Open index.html in any browser. No installation needed.

To edit links (Google Forms, email, social media): open index.html in a text editor
and find the CONFIG block at the start of the <script> section.

To change the logo: the logo is embedded in index.html (search for "data:image/jpeg").
The original file is in assets/apex-logo.png.

Deployment (free): upload this folder to Netlify, Vercel, GitHub Pages or Cloudflare Pages.
